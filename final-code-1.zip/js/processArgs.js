const yargs = require('yargs')
const argv = yargs
  .command('$0', 'Deploys a HelloWorld contract')
  .command('setMessage', 'Sets a message in a contract')
  .command('getMessage', 'Gets a message in a contract')
  .option('address', {
      alias: 'a',
      description: 'The HelloWorld contract address',
      type: 'string'
  })
  .option('message', {
      alias: 'm',
      description: 'The message to be configured in the HelloWorld contract',
      type: 'string'
  })
  .help()
  .alias('help', 'h').argv;

let command = 'deploy'
let address = argv.address
let message = argv.message
let errors = []

const errorIfEmpty = (option, value) => value === '' &&
  errors.push(`The "${option}" option should not be empty!`)
const errorIfUndefinedOrEmpty = (option, value) => {
  value === undefined && errors.push(`Please, define the "${option}" option!`)
  errorIfEmpty(option, value)
}
const errorIfNotAddress = (address) =>
  (address && address.startsWith('0x')) ||
  errors.push(`The address "${address}" is not valid!`)

if (argv._.includes('setMessage')) {
  command = 'setMessage'
  errorIfNotAddress(address)
  errorIfUndefinedOrEmpty('message', message)
} else if (argv._.includes('getMessage')) {
  command = 'getMessage'
  errorIfNotAddress(address)
} else {
  errorIfEmpty('message', message)
}

module.exports = { command, address, message, errors }
