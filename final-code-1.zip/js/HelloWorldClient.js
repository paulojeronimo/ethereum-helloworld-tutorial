const Web3 = require('web3');
const web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'))
const { abi, evm } = require('./compile')

function printTx({transactionHash, gasUsed, blockNumber}) {
  console.log(`\tTransaction: ${transactionHash}\n\tGas usage: ${gasUsed}\n\tBlock number: ${blockNumber}`)
}

async function deploy(accounts) {
  console.log('A HelloWorld contract will be deployed')
  let tx = null
  const helloWorld = await new web3.eth.Contract(abi)
    .deploy({data: evm.bytecode.object, arguments: []})
    .send({from: accounts[0], gas: '1000000'})
    .on('receipt', (receipt) => tx = receipt)
  printTx(tx, helloWorld)
  console.log('HelloWorld successfully deployed at', helloWorld.options.address)
  return helloWorld
}

async function setMessage(helloWorld, message, accounts, callback) {
  console.log(`Calling setMessage("${message}")`)
  const tx = await helloWorld.methods.setMessage(message)
    .send({from: accounts[0]})
  printTx(tx, helloWorld)
  callback(helloWorld)
}

async function getMessage(helloWorld) {
  const message = await helloWorld.methods.message().call()
  console.log(`Message: ${message}`)
  return helloWorld
}

async function getMessageAt(address) {
  let helloWorld = null
  try {
    console.log(`Looking for a HelloWorld contract at ${address}`)
    helloWorld = await getMessage(new web3.eth.Contract(abi, address))
  } catch (error) {
    console.log('HelloWorld not found!')
  }
  return helloWorld
}

async function setMessageAt(address, message, accounts) {
  console.log(`Setting the message "${message}" for a HelloWorld contract"`)
  const helloWorld = await getMessageAt(address)
  if (helloWorld !== null) {
    await setMessage(helloWorld, message, accounts, getMessage)
  }
}

async function afterConnect({ command, address, message }) {
  console.log(`web3 is connected!\nweb3.version: ${web3.version}`)
  const accounts = await web3.eth.getAccounts()
  console.log(`command: ${command}`)
  switch (command) {
    case 'deploy':
      helloWorld = await deploy(accounts)
      await getMessage(helloWorld)
      if (message) {
        setMessage(helloWorld, message, accounts, getMessage)
      }
      break
    case 'getMessage':
      await getMessageAt(address)
      break
    case 'setMessage':
      await setMessageAt(address, message, accounts)
      break
  }
}

const args = require('./processArgs')
if (args.errors.length > 0) {
  args.errors.forEach((error) => console.log(error))
  process.exit(1)
}

web3.eth.net.isListening()
  .then(() => afterConnect(args))
  .catch((error) => console.log(error))
